<?
	include "configurations/db.php";
	if (isset($_COOKIE[session_name()]))
	{
		session_start();
	}
	else header ("Location: index.php");
	if (isset($_GET['exit']) && $_GET['exit']==true)
	{
		$query = "UPDATE users SET Token = NULL WHERE Token = '".$_COOKIE["token"]."'"; 
		$result = mysqli_query($link,$query);
		setcookie(session_name(), "", time()-3600, "/");
		session_destroy;
		header ("Location: index.php");
	}
	$query = "SELECT id, FIO, Email, Phone, Birthday FROM users WHERE Token = '".$_COOKIE["token"]."'";
	$result = mysqli_query($link,$query);
	$profile = mysqli_fetch_assoc($result);
	
	if (!empty($_POST['fio']) || !empty($_POST['phone']) || !empty($_POST['date']) || !empty($_POST['email']))
	{
		$query = "UPDATE users SET ";
		if (!empty($_POST['fio'])) 		$query .= "FIO = '".$_POST['fio']."'";
		if (!empty($_POST['phone'])) 		$query .= ", Phone = '".$_POST['phone']."'";
		if (!empty($_POST['date'])) 	$query .= ", Birthday = '".$_POST['date']."'";
		if (!empty($_POST['email'])) 	$query .= ", Email = '".$_POST['email']."'";
		$query .= " WHERE Token = '".$_COOKIE["token"]."'"; 
		$query = str_replace("SET ,", "SET", $query);
		$result = mysqli_query($link,$query);
		header ("Location: lk.php");
	}
	$query = "SELECT * FROM booking JOIN flights ON flights.id = id_flight WHERE id_user = ". $profile['id'];
	$result = mysqli_query($link,$query);
	$counter = 0;
	
	while($res = mysqli_fetch_assoc($result))
	{
		$flights[$counter] = $res;
		$counter++;
	}
?>

<!DOCTYPE HTML>
<html>
  <head>
	<meta charset="UTF-8">
	<link rel="icon" href="./Images/1.png" type="image/x-icon">  
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<title>AIRPLANE</title>
	<style>
	@import url('https://fonts.googleapis.com/css2?family=Play:wght@700&display=swap');
	body
	{
	height:800px;
	font-family: 'Play', sans-serif;
	background-image:url(./Images/2.jpg);
	background-size:100%;
	}
	.form
	{
		margin-right:auto;
		margin-left:auto;
		margin-top: 20px;
		margin-bottom: 170px;
		width:700px;
		background-color:white;
		border:2px solid lightgray;
		border-radius:10px;
		font-family: 'Source Sans Pro', sans-serif;
	}
	.mb-3
	{
		margin-top:10px;
		display: inline-block;
	}
	.form > .mb-3
	{
	margin-left:10px;
	margin-right:10px;
	}
	.mb-3 > input#exampleInputDesc1
	{
		height:100px;
	}
	.pagination
	{
		margin-right:auto;
		margin-left:auto;
		width:250px;
		margin-top:4%;
	}
	.page-link 
	{
		background-color:white;
		color:black;
		font-family: 'Source Sans Pro', sans-serif;
	}
	.page-item > a:hover
	{
		background-color:#00BFFF;
		color:white;
	}
	.list
	{
		margin-top:30px;
		margin-left:auto;
		margin-right:auto;
		width:900px;
		height:400px;
		text-align:center;
		
	}
	.list-group-item
	{
		height:80px;
		width:300px;
	}
	.footer
	{
	margin-top: 30px;
	padding: 20px 100px;
	}
	.underfooter{
	margin-top: 5px;
	padding: 20px 0;
	display: flex;
	justify-content: space-between;
	align-items: center;
	border-top: 3px solid #191970;
	margin-top:250px;
	}
	.boximg{
	display: flex;
	}
	.boxitem{
	box-sizing: content-box;
	border-radius: 50%;
	padding: 0px;
	width: 75px;
	margin:  0 10px;
	}
	.footertext{
	font-weight: 600;
	font-size: 16px;
	Color:white;
	}
.tab {
    overflow: hidden;
    border: 1px solid #FFFFFF;
    background-color: #00BFFF;
	margin-left:auto;
	margin-right:auto;
}


.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
}


.tab button:hover {
    background-color: #A9A9A9;
}


.tab button.active {
    background-color: #f2f8ff;
  color: #00BFFF;
}


.tabcontent {
    display: none;
    padding: 6px 12px;
}
	.blue {
	 background-color:#ADD8E6;
	}
	.table{
		margin-top: 20px;
		width: 70% !important;
	}
	</style>
  </head>
  <body>
   <div class="preview1">
  <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #FFFAF0;">
  <div class="container-fluid">
    <a class="navbar-brand" style="color:#00BFFF">AIRPLANE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="./index.php" style="color:#00BFFF; font-weight:bold;">О компании</a>
        </li>
		<?if (!isset($_COOKIE[session_name()])){?>
        <li class="nav-item dropdown">
          <a class="nav-link" href="./authorization.php" style="color:#00BFFF; font-weight:bold;">Вход</a>
        </li>
		<?}else{?>
        <li class="nav-item">
          <a class="nav-link" href="./search.php"  style="color:#00BFFF; font-weight:bold;">Поиск рейсов</a>
        </li>
		<li class="nav-item dropdown">
          <a class="nav-link" href="./lk.php" style="color:#00BFFF; font-weight:bold;  margin-left:1250px;">Личный кабинет</a>
        </li>
		<li class="nav-item dropdown">
          <a class="nav-link" href="?exit=true" style="color:#00BFFF; font-weight:bold;">Выход</a>
        </li>
		<?}?>
      </ul>
    </div>
  </div>
</nav>
<h1 style="font-size:70px; color: #00BFFF; text-align: center; margin-top:20px; text-shadow: 3px 3px 3px #000;">Личный кабинет</h1>
<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;

    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
</script>
<div class="tab" style= "width: 600px; height:55px;">
	<button class="tablinks" style= "width: 30%" onclick="openCity(event, 'Профиль')">Профиль</button>
	<button class="tablinks" style= "width: 40%" onclick="openCity(event, 'Редактирование')">Редактирование профиля</button>
	<button class="tablinks" style= "width: 30%" onclick="openCity(event, 'Просмотр')">Просмотр билетов</button>
</div>

<div id="Профиль" class="tabcontent">
	<div class="d-flex justify-content-center">
		<div class="card" style="width: 18rem;">
			<div class="card-body">
				<p class="card-text"><b>ФИО:</b><br><?echo $profile['FIO']?></p>
				<p class="card-text"><b>Дата рождения:</b><br><?echo $profile['Birthday']?></p>
				<p class="card-text"><b>Номер телефона:</b><br><?echo $profile['Phone']?></p>
				<p class="card-text"><b>Email:</b><br><?echo $profile['Email']?></p>
			</div>
		</div>
	</div>
</div>
<div id="Редактирование" class="tabcontent">
<form class="form" method="POST" action="">
 <div class="mb-3">
	<label for="exampleInputPassword1" class="form-label" style="font-family: 'Source Sans Pro', sans-serif;font-weight: bold; width: 150px;">ФИО</label>
		<input type="name" class="form-control" style="width: 300px;" id="exampleInputName1" name="fio">
				<div id="emailHelp" class="form-text" style="font-family: 'Play', sans-serif;" ></div>
	</div>
	<div class="mb-3">
		<label for="exampleInputName1" class="form-label" style="font-family: 'Source Sans Pro', sans-serif;font-weight: bold;">Номер телефона</label>
			<input type="name" class="form-control" style="width: 200px;" id="exampleInputName1" name="phone" >
				<div id="emailHelp" class="form-text" style="font-family: 'Play', sans-serif;" ></div>
	</div>
	<div class="mb-3" style="width: 150px;">
		<label for="exampleInputEmail1" class="form-label" style="font-family: 'Source Sans Pro', sans-serif;font-weight: bold;">Дата рождения</label>
			<input type="date" class="form-control" id="date" name="date" placeholder="Дата">
				<div id="emailHelp" class="form-text" style="font-family: 'Play', sans-serif;"></div>
	</div>
	<div class="mb-3" style="width: 200px;">
		<label for="exampleInputEmail1" class="form-label" style="font-family: 'Source Sans Pro', sans-serif;font-weight: bold;">Email</label>
			<input type="email" class="form-control" style="width: 250px;" name="email" id="exampleInputEmail1" aria-describedby="emailHelp">
				<div id="emailHelp" class="form-text" style="font-family: 'Play', sans-serif;"></div>
	</div>
	<div class="mb-3">
		<button type="submit" class="btn btn-success" style="background-color:#00BFFF; font-size:25px; font-family: 'Play', sans-serif; margin-left:80px;">Сохранить</button>
	</div>
</form>
</div>
<div id="Просмотр" class="tabcontent">
	<div class="d-flex justify-content-center">
		<table class="table blue" style="width:100%">
			<thead>
			 <tr>
				<th scope="col">№</th>
				<th scope="col">Номер самолета</th>
				<th scope="col">Класс</th>
				<th scope="col">Город вылета</th>
				<th scope="col">Город прибытия</th>
				<th scope="col">Туда</th>
				<th scope="col">Обратно</th>
				<th scope="col">Цена</th>
			</tr>
			</thead>
			<tbody>
			<?for($i=0; $i<count($flights); $i++){?>
			<tr>
				<th scope="row"><?=$i+1?></th>
				<td><?=$flights[$i]['Flight']?></td>
				<td><?=$flights[$i]['Class']?></td>
				<td><?=$flights[$i]['Departure']?></td>
				<td><?=$flights[$i]['Destination']?></td>
				<td><?=$flights[$i]['Date_flight']?></td>
				<td><?=$flights[$i]['Date_back']?></td>
				<td><?=$flights[$i]['Price']?></td>
			</tr>
			<?}?>
			<tbody>
		</table>
	</div>
</div>

<footer class="footer">
	<div class="underfooter">
	<p class="under-footer__text" style="color:#FFFFFF;">© Авиакомпания «Эирплейн» 2014-2022</p>
	<div class="boximg">
			<img src="./Images/13.png" alt="" class="boxitem" style="cursor: progress;">
			<img src="./Images/14.png" alt="" class="boxitem" style="cursor: progress;">
			<img src="./Images/15.png" alt="" class="boxitem" style="cursor: progress;">
		</div>
	</div>
</div>
</body>
</html>
