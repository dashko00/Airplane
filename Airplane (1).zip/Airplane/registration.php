<?
	function Registration($email, $password, $fio, $date, $phone)
	{
		include "configurations/db.php";
		
		$query = "SELECT Email FROM users WHERE Email = '$email'";
		
		$result = mysqli_query($link, $query);
		$result = mysqli_fetch_array($result);
		
		if (empty($result))
		{
			$query = "INSERT INTO users(Email, Password, FIO, Birthday, Phone) VALUES ('$email','".password_hash($password, PASSWORD_DEFAULT)."','$fio', '$date', '$phone')";
			$result = mysqli_query($link,$query);
			header ("Location: authorization.php");
		}
		else 
		{
			return "Пользователь с таким email уже существует!";
		}
		
		mysqli_close($link);
	}
	if (!empty($_POST['email']) && !empty($_POST['fio']) && !empty($_POST['date']) && !empty($_POST['phone']) && !empty($_POST['password']))
	{
		echo "<p align=center>".Registration($_POST['email'], $_POST['password'], $_POST['fio'], $_POST['date'], $_POST['phone'])."</p>";
	}
?>
<!DOCTYPE HTML>
<html>
  <head>
	<meta charset="UTF-8">
	<link rel="icon" href="./Images/1.png" type="image/x-icon"> 
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<title>AIRPLANE</title>
	<style>
	@import url('https://fonts.googleapis.com/css2?family=Play:wght@700&display=swap');
	body
	{
		font-family: 'Play', sans-serif;
		height:700px;
		background-attachment:fixed;
		background-image:url(./Images/2.jpg);
		background-size:100%;
	}
	.form
	{
		margin-right:auto;
		margin-left:auto;
		width:500px;
		background-color:white;
		border:2px solid lightgray;
		border-radius:10px;
		font-family: 'Caveat', cursive;
	}
	.mb-3
	{
		margin-top:10px;
	}
	.form > .mb-3
	{
	margin-left:10px;
	margin-right:10px;
	}
	.pagination
	{
		margin-right:auto;
		margin-left:auto;
		width:250px;
		margin-top:4%;
	}
	.page-link 
	{
		background-color:white;
		color:black;
		font-family: 'Caveat', cursive;
	}
	.page-item > a:hover
	{
		background-color:#00BFFF;
		color:white;
	}
	.footer
	{
	margin-top: 30px;
	padding: 20px 100px;
	}
	.underfooter{
	margin-top: 5px;
	padding: 20px 0;
	display: flex;
	justify-content: space-between;
	align-items: center;
	border-top: 3px solid #191970;
	}
	.boximg{
	display: flex;
	}
	.boxitem{
	box-sizing: content-box;
	border-radius: 50%;
	padding: 0px;
	width: 75px;
	margin:  0 10px;
	}
	.footertext{
	font-weight: 600;
	font-size: 16px;
	Color:white;
	}
	</style>
  </head>
  <body>
 <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #FFFAF0;">
  <div class="container-fluid">
    <a class="navbar-brand" style="color:#00BFFF">AIRPLANE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="./index.php" style="color:#00BFFF; font-weight:bold;">О компании</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="./authorization.php" style="color:#00BFFF; font-weight:bold;">Вход</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<h1 style="font-size:70px; color: #00BFFF; text-align: center; margin-top:50px; text-shadow: 3px 3px 3px #000;">Online-регистрация</h1>

<form class="form" method="POST" action="">
	<div class="mb-3">
		<label for="exampleInputName1" class="form-label"style="font-family: 'Source Sans Pro', sans-serif;font-weight: bold;">ФИО</label>
			<input type="text" class="form-control" id="exampleInputName1" name="fio">
				<div id="emailHelp" class="form-text" style="font-family: 'Play', sans-serif;">Образец написания: Иванов Иван Иванович</div>
	</div>
	<div class="mb-3">
		<label for="exampleInputName1" class="form-label"style="font-family: 'Source Sans Pro', sans-serif;font-weight: bold;">Дата рождения</label>
			<input type="date" class="form-control" id="exampleInputName1" name="date">
				<div id="emailHelp" class="form-text" style="font-family: 'Play', sans-serif;">Образец написания: дд.мм.гггг</div>
	</div>
	<div class="mb-3">
		<label for="exampleInputName1" class="form-label"style="font-family: 'Source Sans Pro', sans-serif;font-weight: bold;">Номер телефона</label>
			<input type="tel" class="form-control" id="exampleInputName1" name="phone">
	</div>
	 <div class="mb-3">
		<label for="exampleInputName1" class="form-label"style="font-family: 'Source Sans Pro', sans-serif;font-weight: bold;">Пароль</label>
			<input type="password" class="form-control" id="exampleInputName1" name="password">
				<div id="emailHelp" class="form-text" style="font-family: 'Play', sans-serif;">Пароль должен содержать не менее восьми символов </div>
	</div>
	<div class="mb-3">
		<label for="exampleInputEmail1" class="form-label"style="font-family: 'Source Sans Pro', sans-serif;font-weight: bold;">Email адрес</label>
			<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email">
	</div>
	<div class="mb-3">
		<button type="submit" class="btn btn-success" style="background-color:#00BFFF; font-size:25px; font-family: 'Play', sans-serif;" >Зарегистрироваться</button>
	</div>
</form>
<footer class="footer">
	<div class="underfooter">
	<p class="under-footer__text" style="color:#FFFFFF;">© Авиакомпания «Эирплейн» 2014-2022</p>
	<div class="boximg">
			<img src="./Images/13.png" alt="" class="boxitem" style="cursor: progress;">
			<img src="./Images/14.png" alt="" class="boxitem" style="cursor: progress;">
			<img src="./Images/15.png" alt="" class="boxitem" style="cursor: progress;">
		</div>
	</div>
</div>
</body>
</html>
