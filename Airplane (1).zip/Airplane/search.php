<?
	include "configurations/db.php";
	$url = $_SERVER['REQUEST_URI'];
	if (isset($_COOKIE[session_name()]))
	{
		session_start();
	}
	else header ("Location: index.php");
	if (isset($_GET['exit']) && $_GET['exit']==true)
	{
		$query = "UPDATE users SET Token = NULL WHERE Token = '".$_COOKIE["token"]."'"; 
		$result = mysqli_query($link,$query);
		setcookie(session_name(), "", time()-3600, "/");
		session_destroy;
		header ("Location: index.php");
	}
	
	$query = "SELECT id FROM users WHERE Token = '".$_COOKIE["token"]."'";
	$result = mysqli_query($link,$query);
	$profile = mysqli_fetch_assoc($result);
	
	$query = "SELECT * FROM flights WHERE Flight > 0";
	if (!empty($_GET['buyID']))
	{
		$query .= " AND id = '".$_GET['buyID']."'";
	}
	if (!empty($_POST['class']) || !empty($_POST['departure']) || !empty($_POST['destination']) || !empty($_POST['date1']) || !empty($_POST['date2']) || !empty($_POST['capacity']))
	{
		if(!empty($_POST['class'])) $query .= " AND Class = '".$_POST['class']."'";
		if(!empty($_POST['departure'])) $query .= " AND Departure = '".$_POST['departure']."'";
		if(!empty($_POST['destination'])) $query .= " AND Destination = '".$_POST['destination']."'";
		if(!empty($_POST['date1'])) $query .= " AND Date_flight = '".$_POST['date1']."'";
		if(!empty($_POST['date2'])) $query .= " AND Date_back = '".$_POST['date2']."'";
		if(!empty($_POST['capacity'])) $query .= " AND Capacity = '".$_POST['capacity']."'";
	}
	$result = mysqli_query($link,$query);
	$counter = 0;
	while($res = mysqli_fetch_assoc($result))
	{
		$flights[$counter] = $res;
		$counter++;
	}
	
	if (!empty($_GET['buyID']) && $_GET['answer'] == "Yes")
	{
		$query = "INSERT INTO booking (id_user, id_flight) VALUES ('".$profile['id']."','".$_GET['buyID']."')";
		$result = mysqli_query($link,$query);
		echo $query;
		$query = "UPDATE flights SET Capacity = '".($flights[0]['Capacity'] - 1)."' WHERE id = '".$_GET['buyID']."'";
		$result = mysqli_query($link,$query);
		header ("Location: search.php");
	}
?>

<!DOCTYPE HTML>
<html>
  <head>
	<meta charset="UTF-8">
	<link rel="icon" href="./Images/1.png" type="image/x-icon">  
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<title>AIRPLANE</title>
	<style>
	@import url('https://fonts.googleapis.com/css2?family=Play:wght@700&display=swap');
	body
	{
		font-family: 'Play', sans-serif;
		height:700px;
		background-attachment:fixed;
		background-image:url(./Images/2.jpg);
		background-size:100%;
	}
	.form
	{
		margin-right:auto;
		margin-left:auto;
		margin-top: 60px;
		width:1300px;
		background-color:#ADD8E6;
		border:2px solid lightgray;
		border-radius:10px;
		font-family: 'Source Sans Pro', sans-serif;
		height:150px;
		
	}
	.mb-3
	{
		margin-top:10px;
		display: inline-block;
		
	}
	.form > .mb-3
	{
	margin-left:10px;
	margin-right:10px;
	
	}
	.pagination
	{
		margin-right:auto;
		margin-left:auto;
		width:250px;
		margin-top:13%;
	}
	.page-link 
	{
		background-color:white;
		color:black;
		font-family: 'Source Sans Pro', sans-serif;
	}
	.page-item > a:hover
	{
		background-color:#00BFFF;
		color:white;
	}
	.footer
	{
	margin-top: 10px;
	padding: 20px 100px;
	}
	.underfooter{
	margin-top: 5px;
	padding: 20px 0;
	display: flex;
	justify-content: space-between;
	align-items: center;
	border-top: 3px solid #191970;
	}
	.boximg{
	display: flex;
	}
	.boxitem{
	box-sizing: content-box;
	border-radius: 50%;
	padding: 0px;
	width: 75px;
	margin:  0 10px;
	}
	.footertext{
	font-weight: 600;
	font-size: 16px;
	Color:white;
	}
	.blue {
	 background-color:#ADD8E6;
	}
	</style>
  </head>
  <body>
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #FFFAF0;">
  <div class="container-fluid">
    <a class="navbar-brand" style="color:#00BFFF">AIRPLANE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="./index.php" style="color:#00BFFF; font-weight:bold;">О компании</a>
        </li>
		<?if (!isset($_COOKIE[session_name()])){?>
        <li class="nav-item dropdown">
          <a class="nav-link" href="./authorization.php" style="color:#00BFFF; font-weight:bold;">Вход</a>
        </li>
		<?}else{?>
        <li class="nav-item">
          <a class="nav-link" href="./search.php"  style="color:#00BFFF; font-weight:bold;">Поиск рейсов</a>
        </li>
		<li class="nav-item dropdown">
          <a class="nav-link" href="./lk.php" style="color:#00BFFF; font-weight:bold;  margin-left:1250px;">Личный кабинет</a>
        </li>
		<li class="nav-item dropdown">
          <a class="nav-link" href="?exit=true" style="color:#00BFFF; font-weight:bold;">Выход</a>
        </li>
		<?}?>
      </ul>
    </div>
  </div>
</nav>

<h1 style="font-size:70px; color: #00BFFF; text-align: center; margin-top:20px; text-shadow: 3px 3px 3px #000;">Поиск рейсов</h1>

<form class="form" action="" method="POST">
 <div class="mb-3">
	<label for="exampleInputPassword1" class="form-label" style="font-family: 'Source Sans Pro', sans-serif;font-weight:bold; width: 150px;">Класс</label>
		<select class="form-select" aria-label="Default select example" style="font-family: 'Source Sans Pro', sans-serif;" name = "class">
			<option selected></option>
			<option value="Эконом">Эконом</option>
			<option value="Комфорт">Комфорт</option>
			<option value="Бизнес">Бизнес</option>
		</select>
	</div>
	<div class="mb-3">
		<label for="exampleInputName1" class="form-label" style="font-family: 'Source Sans Pro', sans-serif;font-weight:bold;">Город вылета</label>
			<input type="text" class="form-control" style="width: 200px;" id="exampleInputName1" name = "departure">
				<div id="emailHelp" class="form-text" style="font-family: 'Source Sans Pro', sans-serif;" ></div>
	</div>
	</div>
	<div class="mb-3" style="width: 200px;">
		<label for="exampleInputEmail1" class="form-label" style="font-family: 'Source Sans Pro', sans-serif;font-weight:bold;">Город прибытия</label>
			<input type="text" class="form-control" style="width: 200px;" id="exampleInputEmail1" aria-describedby="emailHelp" name = "destination">
				<div id="emailHelp" class="form-text" style="font-family: 'Source Sans Pro', sans-serif;"></div>
	</div>
	<div class="mb-3" style="width: 150px;">
		<label for="exampleInputEmail1" class="form-label" style="font-family: 'Source Sans Pro', sans-serif;font-weight:bold;">Туда</label>
			<input type="date" class="form-control" id="date" name="date1" placeholder="Дата">
				<div id="emailHelp" class="form-text" style="font-family: 'Source Sans Pro', sans-serif;"></div>
	</div>
	<div class="mb-3" style="width: 150px;">
		<label for="exampleInputEmail1" class="form-label" style="font-family: 'Source Sans Pro', sans-serif;font-weight:bold;">Обратно</label>
			<input type="date" class="form-control" id="date" name="date2" placeholder="Дата" >
				<div id="emailHelp" class="form-text" style="font-family: 'Source Sans Pro', sans-serif;"></div>
	</div>
	<div class="mb-3" style="width: 150px;">
		<label for="exampleInputEmail1" class="form-label" style="font-family: 'Source Sans Pro', sans-serif;font-weight:bold;">Количество пассажиров</label>
			<input type="number" class="form-control" id="capacity" name="capacity" placeholder="Кол-во пассажиров">
				<div id="emailHelp" class="form-text" style="font-family: 'Source Sans Pro', sans-serif;"></div>
	</div>
	<div class="mb-3">
		<button type="submit" class="btn btn-success" style="background-color:#00BFFF; font-size:25px; font-family: 'Play', sans-serif;">Найти</button>
	</div>
</form>
<br><br><br><br>
<table class="table blue" style="width:100%">
	<thead>
	 <tr>
		<th scope="col">№</th>
		<th scope="col">Номер самолета</th>
		<th scope="col">Класс</th>
		<th scope="col">Город вылета</th>
		<th scope="col">Город прибытия</th>
		<th scope="col">Туда</th>
		<th scope="col">Обратно</th>
		<th scope="col">Количество пассажиров</th>
		<th scope="col">Цена</th>
		<th scope="col"></th>
	</tr>
	</thead>
	<tbody>
	<?for($i=0; $i<count($flights); $i++){?>
	<tr>
		<th scope="row"><?=$i+1?></th>
		<td><?=$flights[$i]['Flight']?></td>
		<td><?=$flights[$i]['Class']?></td>
		<td><?=$flights[$i]['Departure']?></td>
		<td><?=$flights[$i]['Destination']?></td>
		<td><?=$flights[$i]['Date_flight']?></td>
		<td><?=$flights[$i]['Date_back']?></td>
		<td><?=$flights[$i]['Capacity']?></td>
		<td><?=$flights[$i]['Price']?></td>
		<td><button type="button" onclick="window.location.href ='?buyID=<?=$flights[$i]['id']?>'">Купить</button></td>
	</tr>
	<?}?>
	<tbody>
</table>
<br>
<?if (!empty($_GET['buyID'])){?>
	<p align="center" style="color: white">Вы уверены, что хотите приобрести этот билет?</p>
	<p align="center"><button onClick="window.location.href ='<?=$url?>&answer=Yes'">Да</button> <button onClick="window.location.href ='search.php'">Нет</button></p>
<?}?>
<br><br><br><br>
<footer class="footer">
	<div class="underfooter">
	<p class="under-footer__text" style="color:#FFFFFF;">© Авиакомпания «Эирплейн» 2014-2022</p>
	<div class="boximg">
			<img src="./Images/13.png" alt="" class="boxitem" style="cursor: progress;">
			<img src="./Images/14.png" alt="" class="boxitem" style="cursor: progress;">
			<img src="./Images/15.png" alt="" class="boxitem" style="cursor: progress;">
		</div>
	</div>
</div>
</body>
</html>
