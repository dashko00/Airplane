<?
	include "configurations/db.php";
	if (isset($_COOKIE[session_name()]))
	{
		session_start();
	}
	if (isset($_GET['exit']) && $_GET['exit']==true)
	{
		$query = "UPDATE users SET Token = NULL WHERE Token = '".$_COOKIE["token"]."'"; 
		$result = mysqli_query($link,$query);
		setcookie(session_name(), "", time()-3600, "/");
		session_destroy;
		header ("Location: index.php");
	}
?>

<!DOCTYPE HTML>
<html lang="ru">
  <head>
	<meta charset="UTF-8">
	<link rel="icon" href="./Images/1.png" type="image/x-icon"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <title>AIRPLANE</title>
    <style>
	@import url('https://fonts.googleapis.com/css2?family=Play:wght@700&display=swap');
	body
	{
		height:700px;
		background-attachment:fixed;
		background-image:url(./Images/2.jpg);
		background-size:100%;
	}
	.preview1
	{
	height:1000px;
	font-family: 'Play', sans-serif;
	font-size:18px;
	}
	.preview2
	{
	color: #00BFFF;
	text-shadow: 3px 3px 3px #000;
	text-align: center;
	font-size:75px;
	height:850px;
	width:100%;
	background-color:#FFFFFF;
	background-size: 100%;
	}
	.breadcrumb > li > a
	{
	margin-left:5px;
	color:#f24147;
	font-family: 'Caveat', cursive;
	}
	.breadcrumb-item.active {
    color: #f24147;
	font-family: 'Caveat', cursive;
	}
	.greeting1
	{	
		margin-top: 100px;
		text-align: center;
		font-size:75px;
		margin-bottom:10px;
		color:red;
	}
	.greeting2
	{
		text-indent: 80px;
		margin-top:40px;
		color: red;
		text-align: justify;
		font-size:25px;
	}
	.greeting3
	{
		font-family: 'Play', sans-serif;
		text-align: center;
		font-size:75px;
		margin-bottom:10px;
		color:#00BFFF;
		text-shadow: 3px 3px 3px #000;
		
	}
	.undergreeting3
	{
		text-indent: 30px;
		margin-top:40px;
		color: #FFFAF0;
		text-align: justify;
		font-size:30px;
		font-weight:bold;
		font-family: 'Source Sans Pro', sans-serif;
		text-shadow: 0px 0px 0px #000;
	}
	.h2
	{
	margin-top:120px;
	}
	.slaidlist
	{
		width: 1000px;
        margin-left:auto;
		margin-right:auto;
        margin-top: 100px;
	}
	.row
	{
		max-width:100%;
		padding:100px;
	}
	.row > div:hover
	{
		cursor:pointer;
		transform: scale(1.05);
		transition: transform .1s;
		border: 2px solidgray;
	box-shadow: 1 1 10 px rgba(1,1,1,1);
	}
	.card
	{
		margin-left:auto;
		margin-right:auto;
		border:8px solid;
		border-radius: 40px;
		color:#00BFFF;
		margin-top:-100px;
		
	}
	.money
	{
		text-align: left;
		font-size:20px;
		color:#f24147;
	}
	.activities{
		width:100%;
		color:#FFFFFF;
	}
	.pagination
	{
		margin-right:auto;
		margin-left:auto;
		width:295px;
		margin-top:20px;
		
	}
	.page-link 
	{
		background-color:white;
		color:black;
		font-family: 'Source Sans Pro', sans-serif;
	}
	.page-item > a:hover
	{
		background-color:#00BFFF;
		color:white;
	}
	.buy
	{
	font-family: 'Play', sans-serif;
	
	}
	.list
	{
		margin-top:30px;
		margin-left:auto;
		margin-right:auto;
		width:900px;
		height:400px;
		text-align:center;
		
	}
	.list-group-item
	{
		height:80px;
		width:300px;
	}
	.position-fixed
	{
		width:620px;	
		position: fixed; 
    		right: 0; bottom: 0;
		opacity:0.1;
	}
	.position-fixed:hover
	{
		opacity:1;
	}
	.footer
	{
	margin-top: 30px;
	padding: 20px 100px;
	}
	.underfooter{
	margin-top: 5px;
	padding: 20px 0;
	display: flex;
	justify-content: space-between;
	align-items: center;
	border-top: 3px solid #191970;
	}
	.boximg{
	display: flex;
	}
	.boximg{
	display: flex;
	}
	.boxitem{
	box-sizing: content-box;
	border-radius: 50%;
	padding: 0px;
	width: 75px;
	margin:  0 10px;
	}
	.card-text
	{
	color:black;
	font-size: 20px;
	}
    </style>
  </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
<div class="preview1">
  <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #FFFAF0;">
  <div class="container-fluid">
    <a class="navbar-brand" style="color:#00BFFF">AIRPLANE</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="./index.php" style="color:#00BFFF; font-weight:bold;">О компании</a>
        </li>
		<?if (!isset($_COOKIE[session_name()])){?>
        <li class="nav-item dropdown">
          <a class="nav-link" href="./authorization.php" style="color:#00BFFF; font-weight:bold;">Вход</a>
        </li>
		<?}else{?>
        <li class="nav-item">
          <a class="nav-link" href="./search.php"  style="color:#00BFFF; font-weight:bold;">Поиск рейсов</a>
        </li>
		<li class="nav-item dropdown">
          <a class="nav-link" href="./lk.php" style="color:#00BFFF; font-weight:bold;  margin-left:1250px;">Личный кабинет</a>
        </li>
		<li class="nav-item dropdown">
          <a class="nav-link" href="?exit=true" style="color:#00BFFF; font-weight:bold;">Выход</a>
        </li>
		<?}?>
      </ul>
    </div>
  </div>
</nav>
<div class="buy">
	<div class="greeting">
	<h2 class="greeting3">AIRPLANE</h2>
	<p class="undergreeting3">Airplane — крупнейшая частная авиакомпания России с самым современным парком воздушных судов на российском рынке. Широкая маршрутная сеть позволяет нашим пассажирам путешествовать в 181 городе и 26 странах мира.
<div class="color1">
	<div class="kim">
	<div>
<div class="row">
<div class="card" style="width: 29rem; border-radius:20px">
  <img src="./Images/7.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <p class="card-text">Airplane получает новые, самые современные лайнеры напрямую с заводов производителей. Пассажиры Airplane могут оценить комфорт и удобство самолетов нового поколения.</p>
  </div>
</div>
<div class="card" style="width: 29rem; border-radius:20px;">
  <img src="./Images/9.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <p class="card-text">Airplane первый внедряет современные технологии и предлагает пассажирам самые актуальные услуги: мобильный посадочный талон, самостоятельная регистрация и отслеживание статуса багажа.</p>
  </div>
</div>
<div class="card" style="width: 29rem; border-radius:20px;">
  <img src="./Images/8.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <p class="card-text">Каждый полет - это уже путешествие, открывающая двери в мир вкусов прямо на борту. Начните свое путешествие на борту авиакомпании Airplane</p>
  </div>
</div>
</div>
	<div class="shop">
<div class="greeting">
	<div class="preview2">У НАС
</div>
<div class="slaidlist" style="margin-top:-700px;">
  <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="Images/4.jpg" class="d-block w-100" alt="..." style="width:800px; height:650px; border-radius:60px;">
      <div class="carousel-caption d-none d-md-block">
	  <h5 style="color:#00BFFF; border:8px solid; background-color:white; border-radius:20px; padding:10px; font-family: 'Source Sans Pro', sans-serif;">Плавная и спокойная посадка</h5>
      </div>
    </div>
    <div class="carousel-item">
      <img src="Images/5.jpg" class="d-block w-100" alt="..." style="width:800px; height:650px;border-radius:60px;">
      <div class="carousel-caption d-none d-md-block">
	  <h5 style="color:#00BFFF; border:8px solid; background-color:white; border-radius:20px; padding:10px;font-family: 'Source Sans Pro', sans-serif;">Быстрый и безопасный полёт</h5>
      </div>
    </div>
    <div class="carousel-item">
      <img src="Images/6.jpg" class="d-block w-100" alt="..." style="width:800px; height:650px;border-radius:60px;">
      <div class="carousel-caption d-none d-md-block">
	  <h5 style="color:#00BFFF; border:8px solid; background-color:white; border-radius:20px; padding:10px; font-family: 'Source Sans Pro', sans-serif;">Комфортные салоны для перелётов</h5>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"  data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Предыдущий</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"  data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Следующий</span>
  </button>
</div>
</div>
</div>


<div class="activities" style="margin-top:70px;">
	<h2 class="greeting3">Багаж</h2>
		<p class="undergreeting3">Наша компания AIRPLANE предлагает услуги перевозки багажа. Ниже Вы можете ознакомиться с нормы бесплатного провоза регистрируемого багажа (на одного пассажира).</p>
<div class="accordion accordion-flush" id="accordionFlushExample" style= "width:600px; margin-left:auto; margin-right:auto;">
  <div class="accordion-item" style="background-color: #6495ED">
    <h2 class="accordion-header" id="flush-headingOne" >
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne" style="color:#FFFFFF; background-color: #00BFFF">
        Класс Бизнес
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample" >
      <div class="accordion-body" style="font-family: 'Source Sans Pro', sans-serif;;"><a>2 места не более 32 кг каждое</a></div>
    </div>
  </div>
  <div class="accordion-item" style="background-color: #6495ED">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo" style="color:#FFFFFF; background-color: #00BFFF">
        Класс Комфорт
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample" >
      <div class="accordion-body" style="font-family: 'Source Sans Pro', sans-serif;;"><a>2 места не более 23 кг каждое</a>  </div>
    </div>
  </div>
  <div class="accordion-item" style="background-color: #6495ED">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree" style="color:#FFFFFF; background-color: #00BFFF">
       Класс Эконом
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample" >
      <div class="accordion-body" style="font-family: 'Source Sans Pro', sans-serif;;"><a> 1 место не более 23 кг</a></div>
    </div>
  </div>
</div>
</div>
<footer class="footer">
	<div class="underfooter">
	<p class="under-footer__text" style="color:#FFFFFF;">© Авиакомпания «Эирплейн» 2014-2022</p>
	<div class="boximg">
			<img src="./Images/13.png" alt="" class="boxitem" style="cursor: progress;">
			<img src="./Images/14.png" alt="" class="boxitem" style="cursor: progress;">
			<img src="./Images/15.png" alt="" class="boxitem" style="cursor: progress;">
		</div>
	</div>
</div>
</body>
</html>
